function mul(x=5,y=6){
    return x * y;
}
console.log(mul());
console.log(mul(9));
console.log(mul(undefined,9));