function sum(x,y){

return x+y;
}

console.log(sum(5,5));